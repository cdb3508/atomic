console.log("douyinbarrage.js");
//拖动图标
const dragDiv=document.createElement('div');
dragDiv.style.backgroundColor='yellowgreen';
dragDiv.style.width='30px';
dragDiv.style.height='30px';
dragDiv.style.left='20px';
dragDiv.style.top='20px';
dragDiv.style.position='absolute';
dragDiv.style.zIndex='200';
dragDiv.style.cursor='move';
dragDiv.style.borderRadius='50%';
//创建画布
const canvas=document.createElement('canvas');
canvas.width=300;
canvas.height=500;
canvas.style.backgroundColor='yellowgreen';
canvas.style.position='absolute';
canvas.style.left='20px';
canvas.style.top='20px';
canvas.style.zIndex='199';
canvas.style.border='none';
//可拖动画布
let isDragging = false;
dragDiv.addEventListener('mousedown', function(e) {
    isDragging = true;
    const offsetX = e.clientX - canvas.offsetLeft;
    const offsetY = e.clientY - canvas.offsetTop;
    document.addEventListener('mousemove', drag);
    function drag(e) {
        if (isDragging) {
            e.preventDefault();
            canvas.style.left = e.clientX - offsetX + 'px';
            canvas.style.top = e.clientY - offsetY + 'px';
            dragDiv.style.left = e.clientX - offsetX + 'px';
            dragDiv.style.top = e.clientY - offsetY + 'px';
        }
    }
    document.addEventListener('mouseup', function() {
        isDragging = false;
        document.removeEventListener('mousemove', drag);
    });
});
document.body.appendChild(dragDiv);
document.body.appendChild(canvas);
//画布内容初始化
//图片数据
const fish_img_src='data:image/png;base64,UklGRg4TAABXRUJQVlA4WAoAAAAQAAAANgAAJwEAQUxQSN8HAAABfyAQSFLYH3iFiEgdrFHbdkiS9Hzt7lV8kb1WRmTOGl2JMTMiar3bUxVfjN3xjm3bWNu2zbFt29oxqqsy33P6vB9qvf8i+u/AbdswEptr1vsJ/rGOW2M2MS+ZRc/xx2fRUcxzZnFm+GWzaGX459jvR8z8tfkB/+3/hyFbtnS07PuX3MY+W8maN3KQrQHg238/dKne4Qcj//k6gNXlc3PKf+D0gKcn5sPteXcL4POCqyXwO9/utd5RWqfHzTAznznfNVrrOE67WWlq+sGQebyn7S3t5nlRGFMTEdGL/HEy8kRpJ8tLQw5D3p2o6sUA0k43TTpZWZP0PeadiKjqKSBJNKB0klnneb6SiIj6ClAQIvus5N2IiIoGnLQ8nztYjoJbkhmymJZnxFqKqqLtHyDqiMciDRkgSjoraDxWCBRN0mrBg2ZZLUWwsbqKwxtQXyHYoGggXJLqWRTh381et79jFk0zLwzvXuafz+J6nvmN4X2SmdcMbPtpZma+coHsgvmOlk+zbZFo2cwWVp9ip4VyffGJnVvAvo+yx9vkOY/DQNpuOqStYPv00NtH4PQZT1vDY9lFro6AX3SB1dpytLOks9/FzMwfaSlRktpLlOamJppirgp5km4rVgAi3TE1EdGQP05kn07eTeO4k4uNHmDehYiKFgBxTFnKV6IhX0lERH1xQXcyQ7YR70pEVLVliJJO6Vh2lKNhi5JBWZND1dNwitLMsZhV46OTrlxMVyOATsXSVgijk5LG5yBUsiL8Bjaqq0bwRJPUD7xFeSM8JLHCf0iTc2bROfzEwvBGzLwguN8w85HBNVcy84fDii5g4c5XB7ThNNsW+2doT8BpTrPb2wEo178+CpjaVSx7j7zzYQDNG/mKH93q33hd+bzsIQ7wUdia3RN+dKn7c2t46cH3h7K1ECDJyhNuYeYPNpS/NK+JppjPrEzLe8bKmuhBZt6FqPCdscmaiFYyn0FEJFatRdFYTkREJwy/RkJfIeq0Uq110ilrcqtaCkg63byXlyV5VK05AKDTLDeGPHfV05B0mnazvCyN/ZdZNS5a6yRJu7l4KNoaAXSSlkRVSyFMc5KoHzoY1GQaYSMy7eAbSd7TCBZpjf+Y1Gya4YWzaMRnzqKzmJfM4kzxx4OL9ptmnhe4XThiZv763JC2n2HLB71tO80u67prXsguntP8Hft9WBbdyEFE246Y/z7y93YAuIE/oABsdJGn1wDAA1vAsnzG1bsAAHPhEH12aLUOvKIky78/YuYz5/s33clrou8xn1m0tSed5oaIaIZ5VzJt5SjSaSY2epD550RkHKtOB2W9auS9MxHZa5RkqzbL70e7kdBXAHQny4s8N4bcTEtMtxvHaZJmpWcUgLSVKgCA7mTi0fm/1rAl3VwsVbFq/KKkUxJV/ZZCkGhA1I8RKJmk8QZCDeqqrxAomiATI1gnbykEi7TC/wc2PvGk9sD0HF21yG7ZwyxdOdfq6Z9bfYcdPm71PL8RAJpT7LRENsW8AFg2w257yqaZ73zlct8wK9GQwxwhGnGgBQAQOnsCsicuf8zblWIivnJNBUT7PuLupaKxkxSEaOIWRz+HMNHXomRQ1idYy53z5fdE1VZAlGSGiOiAP9z2979/ZZOlsh1ovKGipKzJqa9EJVHRSn1D47FoBVFlSvLqKQDNFRRmfA6AqA6rals/Js/z0ngq5HOZt1KdJJ3M1M4bok6sACDSaVbaS19BiGDTaVYaIjL9BgJEOulked6LEUjrRCv8DynqNML79Ij5yh8dtDTo9SG2HOFvw2l22MY7Q3ZaaPdTBTRn2G0DqyZ/XOEF9rjTajnznY+w13zZJzjIx2VncZhForvC2l3+PMm8BdD53GPOjsQqoncCiJJs/0tGVk/Ms9tGTF4TvciPi1kIy9NzgWisrInogB3pgB/+6UtVwyrKYiBZNU49q6bpp0nmGRpXsqSuitw3ZH+OUZC+vDaqgypiGZEpS2M8Hz35M0GmF8dpNze1o56WzxubtgKgddpd4XsDBn0FSWd5bowxRUNBGotha6ZJ0um2Ynug4aG0wv94osXOohTNrKfstv24o+WPsHDnfKtv8EJZdAHbrrTWu/hI0bZDdnm57EnmxQC+zW5nyp5ivnMermef14ieYeYnRuy3AACe5UDzAOD5wBYDsidu9/d1MdF5a84Bon1v8bRElPQUhOb3Ro6OhLCRaYiiJFvxh6HsyoYV9RWAKM1rIvr8pUN+4stVWzagqgXoQUnSA0/sQrT6HNEEUdFKBobcqpayoqKoyaeYAyCaoDBFDACTYVVtiB9T5nlpyKOvAABjrTTRcSdzP1QtCFoBgNJp17X0FHx00slNTUSmFyOATtJuSUU7VggS6UHe0AgWxQr/K9v3R6csDW3DaRb+9uqAvsMOr7OLRNEUO82zemEdAM2V7LaB1Qxv6d2Z77Ri5itn2Guh/IfD7ClazoFeAQB7BfbEIgD4BvPX56G53yOeFgAAzuI9AQB64mZXb4Rw19flDEo64OKhbE9Iv1wAAMmkISKa4juY7zw0lkWDtgaSvCYioj+eSkREq1mVVTtOJmtyK+aImivIFKVvqGrIagrSn4PQHNdYTVVRGOOrEG1UV3maJJ3M1O5RoqoXA9A6zUpjv7UVRHkMSSddeUxPQ0gacNCTJs+LvBVDiuDUacVxHCuEifAPAwBWUDggCAsAAPAyAJ0BKjcAKAE+kTyZSKWjIqEq9Yx4sBIJakRBH0DAv8V2J3ZPBfl10XHV8mt4k4v6kP0J/w/cA8p/+O9Sv9G9A/67/s/78Hos/2fqAf5XqIefi9lH92vSZ//+ce/zjtn/wn44+gfko+KymuWTI14z5L/AJ2iWp/5z0DvYD6h/wPTUmfRW/gfGGPqHz7/nn+c/Zf4Bv5r/aOsb+6vsp/sAf9rUHpA4VKVM48xndRARVv48xkzTdLB9xP/VuUIDgj19Ki3OfhIuxEN/2TTxHUovwAxN/uXzkyx8eX574sEbaC0Qh5YOd5zFThy3/I7PrKjrk2NB5U7mbFrfMvgx+SrKJP5VHkOo0F794KlEoeQ7sEPnTL8UWe2Dnz5jTnKj5xwojVFiAUGHavBQEQf2euWdNief/Xkx0jdJ658mMO+Jfnnh/VREk6QRdg2O4t78lrQ+sqlCu5fsVXSrUaCEvlhYZNIZRqmDH5ulOmHMuIG/2q3FWvpDYaBGLDnU//8uWQ25c5NrSwlx9jcCc8y8CNp+WWCOf8BWBievHb6HFcDIAP7KvOsP6AEAkJMq8yC3rqdQsROb+AgM7xXqpG5yZd3Z+tqeHNHywDrUzHvT7gUdNT1I5y+FcZHz/rQdxactWhxSvIuDn22T3WG8Wkh4gkDcRicnz5H8PnSIpiIVtD2jC9ZrocAN7FBnmwmjdE+c4wCt5GIhMaa22Z1rhoQYcEdWo+2a0VcHEMY9UdYUD/ZGLVSeJaKdsj8mTxEfygABO7OEDhfgAswww4o1DyHUM708Siga35v0t2jE59XQ++7jyf5wmqnkSq2ve58pqywhBneTAMB2jHXH+V+Wl8vsH5BKxozT5frI0NbteeJvC5A6hl5HJPkByXCu6/mfqvadbTpmyCRmKC+oYmOTppoXrltF2ibz0AKE+X8BoYif8yazFQe5dBiKWoPQGH+ubaFCzCx0DlFqjnpFo9hN6Ro3p04cerIaLbsj27260Jh4Axip20k3Yp4LQ3GaZ5Zr544o6FANYH2v8LXhrbpP2WCndhZvfdRe9JN87/iv2GYdgU+ysVidEB6echvR6mZWyu6CdQJyu53wslrAfFMSZQ/h6WdC61jROXxTTqdPV1KrmkzZmKbuIkGtT9A2rwdbty1U+OxHdTWyRGdYgq1z03y7/BcVzdg/HBCuP/o3xk+ylrMC9f4SPq/5EmZZdygvaFqbBCtNQIp81saOfebZM7HkZJ8elDORgQJ9kYyVGVngd7eEagSnUCf+A4LP4tV/lSWpADJkhjxgv0+1oAxDRnk3GJto/ivGfjIuZrl6dAuh6PRZfEDP/o53y/MCkX+OhLwrMXM973EpB29+X/pGERUu9GLMmf19ZYdABMDZzHSsIxKzvz/DxzmyP2hNJlx9L5Qr8VMAAGPGBDDH3OANfvwjZOxS5R9Sgx/qazthJ5Jk0S38tB8ezwFFsS5SnbaESkUwvGXqQkaZhWT6Buo1iUaUB9f9Z2Je3tK3/FrzlV20bmuzOQwua+PnwsoPqmN23s9Z2E2DRt9xh+sdmDz6I9atSwUmL21xPGXX2dm6ztVF2JLiG/A+Oj8iqoMlsT2o1/+gLMAtgHL5J3jgj1FIHuGosJkJoPO4Ps1csCIVQHdzreNH03mv2XHq8WZlJYXQdzpMLdqeIS5yh7D+zxVkRdCHnSRCEdm9PMEEwpshzJ9AcG+9F5bLTr4JEZG5uk1I0gkZ30o5U/qbbzVDNJ++Y9cF3wrsmn3GHzjNcKt99S74/0MTJjuTyvT9y75ovkR8JEfSbkHephXUYbbIAYO9p11Af64EF9rMaLAyqr8OSEqPROJA5WVdesLJA5uXGzPTqpUy4yv4pDtJnKGBrFYN1zNEBtEOPmdTG/hkgzIRcMYm91zNSp4pf8LuBhs8vg7ckg52LOkV2G66l0gG1O1I5qxMZtNRy/F6gmKX5ZZ+R5ciPMMluMdo5NNYJrsC9MlMmHBXBw9MFou+4dcevLJhuBKnsxNUM2OrC0/XNyXCZXV6uSykWBiDaA6iIt/2MTBGSzir4cBYjBTcShq/zkvuu356yuPb2SHn8cjabD1b5XoxRMOGCWr1UuEFugpUKgnA5DaWAoijCk3i+J8E0CrN4VrIv+RiNH8Xj6osLTuJ8gkdKNTscEYprP9GhjwiF7siDH/HDM+ZhRlB9akQhfX9PIcEXLi0G3BviBWwPirFyM8kwbA2gi6ONsWbSwgRzP4W+JJ/+nbYYbZ/nZgBPlYC5x7PMIeRXhFlDdku90vFfuuofc0mTZ9za+vLcKsoXgAEdo+bPflf9DkYiONu5p4JjfDdMNlnE94ral+1k6spFYdKZi1NTam/ePtdwHmlge3J2v9QeJthlC6WLpbe040UaPKhL7E5/SD4JAWc/X+b27nYXdMdfwnhwlJFL0RyEsQK35T6gB9KzrH/3GlzyO39AxenMwBe8pfW91Q9KE8fhs4rqwd2kBYPzdo3ydV+rvmcYu2yLLX9dRfxe6w4lOFsD6MwCvVVVTmmn+c6ZsexbV6CDf24YfjT8poj0NOokZGERrn/jOegwP3msit4OoPjhxVHqBO8iANzJ6fJZVB+ixPTR0u5Qr5G+Of+C+L3w/9lwZ12fiuIRYQsdX3ePR/moKzpb2UW2gg1e/laIIoFal6kD+u2yw7WQIT1zNJ3vX4X99TPsfOFU1iD7kQThHfBNh4SjqEif/txT5NtCYDAI62GxcrWnl8yTt1lW0Bgno4UVtl+QYLP7QfFAnX0cAwisgIvoeK/M4l9rQiYsCyaTqZXyhvNvT3HnNtk/Z36OrAkRfe4PU4gi5wf+9aPL+sBzEWR4PdUZKU2YhFgIiey2+LuvcRr9d635rxncZqBXk2YSjGzKKK3L6w7dcBkEUGbd55R6zK/ywrhn+N3L9pwlEIcdr688IL7tLwUUaZPLFy9d9fvoas8yUakEUuGRDADepz9SMkMmyl7hSXrmb1uEMvlsmequcoRB4FE4nRv+uzOHAiYd0t7bKwav9kHX8VTTg0JcPC43zM7mekETfPOSrb7lLanC9nYK6pptgE9s3ckbbd6vaccHYfuwWplDOommRTR4ghnyPrE7YgOxXR3QdDkiJW+pzpUSlJv7jUuqa+Ylrin0vdyneOIu9WafR3f8o+tu2+rWVEIkDyEAs0l8nMS35xfSNbf7ya2L8V2bSmyadAOC9m8+V24D58Q+GMPgRBx00v/MqGmIJU2f3Ynv9YP7kDm/EqF0PcbI3+xbNdvSpkdCEicTpLUrgGHds+jLQrm6BCBDtOsnisRtGgxUQEa+OYQjzA7jMC9CH7/bLfUehy0gUWaoQKxux/13Uav1tSUyL8Cz/utwbGLUvCw3oMBnv9eBzUZhp6XePW+0WMJRumAOFbX8So0F1Yw0tTjfNw5WVDK2clB/t4P35pSP60ZRj8IxXNhk64Zaqo6MELp++D3fRPnZrpmwn8sHI0P3uTjj1UaAY3IaiBDp51PKMPGd47aAEIE6k4LCSPQQyhgqXEPx5Gotj+Ee3QoWgcB1Pi4TY6LpurpUnyYQQBHxGiygp5AmvLKy35BQzbm/13/StmnJtavJgTetP2x76CSkqD0zIaxNW5ukRIdH7o5GAyxItO+kzcfbr81QBDTM2TI0Js2U/OBAlTxcT2pVTsBZ+5/vAUqPaw9mY0CJkDmkNVdBM8V4jJns7um5C2DRXgOqUtHebxxRzIKP6XHFOMeotvj/EO1q5Of5Qq3rZ/7YQWOl0Uk5wgN1heAAAA=';
const src1='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAABfBJREFUSIltVmuMVVcV/r61z7nn3nnz7JRHgPAqjB0oFU3G0oi00appiQqNNv6xBYom2sRGYzRxfreYlkbFNOWXpjGDrdH+qC9qsE2jkzoFi0AHJC3N8BooMDPcO2fO2evzx50h6ejKTtbKTtZae2Wtb3+LmCUCjIADwPsbVvV4JXnQgm2T2ENyIY008Jyod1MLRyL16uK/HXt7tu+McHYCABjeuHpjmoS9Ine0BJtTaNrLKAIyoxmJ1pBgQp4H8pdlw59eMnhseHYSmzEGgAAAZzat2VVNwp/aQthNYE7dUZaSixABAaAc7g4fj7GEq9IewmO11uS181s27SLgmo51qwIBJKB371rz3ZZg+0oALuQkUzRf6wRnDoxQ0ybVvCuqIVQiAAf3dP/1rednYnI6iU70rnqsmoQDAgxE048GmJEk4C5IAEkzAy2BAZLBjBRBDwYmFtQo+fji1wdfQDMJcGnFig03upIjCdkZgQjCCMKSBCxLxTLSajVktQqMUBELqKwzSTPQMhARbJbmGWlTxIchYsv8vwydTDCwI/z4xIff3vvG5c6ui408Viw1UQhG1evCvAVcvHMHqp++j9duXyv6FLvDMHHpV8jP/VqhuCwk7YQKAaKkoqsdc4sxPaF7sDf0fX7NhlOrO5+eN9oI6z+4GWJiZAj0yUlU1vdy2VP7ePTjX+YzQx144c2cL70jvnNtidqWfpHL1/bRJ4aAcgRIK0RwMsAAwYJWcKm/Em57eO2jaQgPDM/L4uYz46GrIUYvgbYOLHvmOQxoIx//6YgOn8hx4brj3JWIN0/X+YejY+ru7mFvz92MF18RY51UCgiU4CFjmztHLIqfQaPQ1dYkvPTJBcgKVzFV6PYvbcdbc3r5/YMjGiuM3Z2BrRnZViXntyUaz40/HBjR4JXNSJZ/w6IiZAaYgTQiBneF+wziOi+daRH5xh3tGFzRgvakiuoXtuN3/8h15SbRmhmmouACoguli61Vw/nrxMDfG+D8B2VJuyCBDBCClaWZEHrM5QtdQlI6bmRBL35iLvPOKifmLMexDyaRpoRLzSkBbml3oVYhhi/lGtOdSJOM0DQ+zASYCC4wSZCEklDLZImhJS0cXNWmChK4exMD+n8fCiCJDsJjTjDAYQaaJGPTNJmkUaGJIZcYIDy/oYP5+Fnc0V1VY8oRjDMBb2mjqYjQnYsydqX/UVGWspAICISZiEAwXDZAJ0A65HIIqaCztQKHrg9id1+NCzuA8dyRGBWMMAKVQNzMI+e3QdvvrgKjA/CyQVoiCSAMIVCinTR5PIxA8yhJzUbWYPj58VdltZM48Mgi1iqu0YmSE5PSRC5dGHO1V137v7rINi34p+rnXlYIGQVON9kc1UAgvBY6Hlp9NQgPk6i5Q4BoDBjPx/j2xdPYuXElHtm0kl0tibIUXD4/4UO9rdz3lXmcO+84zv/rB1ikM0RoASCClBkBYtyjfkT0w9YteeAXVkt3xZtTOYiKu8NoqBcNdVY68bWPbeP21fejLVmCNKS4PnUWL59+ne+f/Y2eWnScLUlVRJRcRigPbczijXgwjF7YQwBYc/CzG8x5hGRnjB4htyZZBOUx52RRoiXN0JqmAKCJvOBk0cChdVfU11lYEd1JkVIMKZJY+GgoG/dy69VTBoDDj/7xmBd6UvASACFFF1B6yYSpWisZJOn65KTGG3W7Vri+ubhAX5dbCXMy0BCiBTMhlMH4PW69ekr9sBnKJACt/tn930HAszBAhecAK9MjLEAkoKlSXFiJ+O36K1qalSwE0VUkiTJ3R4z+RGXLe/unsakZyhR2IJz+1p/3e4y7AYywlmSCQ+6lXJBLHiOjoD231bG0Jkx5iIFmSWeSKdioxN2VLe/t1w4EsgnPj5K+QBBa8ezWtUj4JKWvMwtZzCPojpuR2txe4sWeMXYkAipArMdrwcpDRdSByqdOH52N9v/dKvph6G9uBcueu/cuip+TuA1UT3Qt+MnKSeyc2xgrAodSlodR4ve858S/AUD9MPZ/dG35L/ocI7neyyY6AAAAAElFTkSuQmCC';
const src2='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAABXRJREFUSImVln2MVVcVxX/73PveG2CGAk4pUEup0tYq5UNMGuNHtIGGhD+AqCSacdIAklZtnYa2QmqbUURREWixf5hW2wgkTZsiJbU2qeikxi9SajF+tCKFqQ1FSscZysx7991z9vKP+XAA08Tz9z1r7bP2Xntd44KjboJ14wC6//rFYDfh3IhYCGpHguRncL0EOojK52zTscMX3h09dh44mIH0/QWLqHA7TgeteU5MMBgLnDO4C2k6E6wKwLlUkuJeSt9pm48fGcW4iGAMfNe8W1C+mdasnf7mAO5P4P5T3Hop0xC5CbdWLM0m+ipgNa35ZN4uTxPjPba59+HxJHYe+I7591AL3yQJGmkPlPfZXa8cv1DG8179tSuvIgvdBOvEBY20yb7z2tZRTBMEA9eO69dTzX5I6Q3KtMnu+svOdwK+iGjT7C6CbSWoRj2usW0nHxkhAT2wYBFJvyQwhXrcYBv/un3s4noqXPXuK4m1uSSmgEfc/o03Xuf1ai+PnihG5dDdl3eR2w6inyHGJbb99BFTNzmT5/2Y1srn6a/vtbtf7gDQt+ZeimVrSFqDfA4iADlySAKnQN5H8kO4nsDL/bbtX4O6c+ZuJmUdDMRHe1469YXAxOvmE1hFf2OAQvcCaMt1M/HsGaq2FekaRJWMnJjOUvo/Sd5HUI0aM2kJK5gY9uD2GQAaQ/fpbNlPpk995P1T5uVgy6iGVhrxIbt3pKEqb6GSfYhzsQmqkHSWIn2Jiv0GH8qILS14aqVIVyP7OG5TseYhAPvBwHHdXnucqq2vkC3LcW6kdCib+8fGKzJnWGsF5CAZJBjgrO043Teut38A9owfdYBU+oGsauvlWpLjaSGDsU6KJ8YM4nEfKXQOu1YJvJUQ9lDVP/TVy3+L+4tE/c52nDo0DjyMzL3LGq9Sr9aRLwigaSTvI7P66If2jRNP0YybSN4gKCMQaDrI55LRSWY7wX6mrhnPx69M71D38KiPvctjXaW/ZdAecBkOJBuuvnvE4lte20pZLiTG7TT9CK4BMkESaiTA2wn6WGbarTPTDvTfytRRkkbEUDIlV07pb2G8i8InjhD8d4989+QrwAbdRo3ajA9T9w8CCxDLkKYrqkTKrGrL28pp34O+dQCxyCfVqrST/M0c9z8yISyhsDmCv41p+gly6yEC2C4KONUD9AAMfrl91gTpFxZ4n0oviYQg3SDIDFJr5rOpZDWSH8mJ8VeosgS00uAZAG2YuZnASi3m98T0azz+HVUGacaSmgIpvVduU3CBu3DLFVNvgDTcA1aiBNF7TBtnLSLPn6f0xFBzse06fUx3zHiaydlyGj7c9uio4UOgflxtVqGNpoMLclDhJ2MzrajuHnpBnbVrUDisoGBF+mjg2Mk/0UxPMsEuoZp9fbiCt9cy0FyrenpKQ/ENGt5AmmholkltaqSo5KWSv0ER72+WzU9Wdw+9AEDJteS0qumPHT5a/nl42d05fT7KDhJopyzvsJ1ndo4Z52ZqTGqbTbT3kOwSsgRNG0RFLyeaR62Hxth4g2sxFa7NltJIL9s+XrWxLOi6bI0CPyKpUIwbswf7/q91Pd7NvjrfLukDWZFuPj9wvnjpRip8GzkU6SekRrc93HjnwPkcV2O1uewtnjWQPp09QIvdpnrqs1I3XBSZ8dZp6zJjCzWmazCd9cTjWSz3Nz30VrN4blhnb0tKVxj5KkOftUyTKLQUWE5VXdT9HEmrbT8//9+hv27qfPAuSR3WQmXYvV7gelMuM9dlVhvJhroi8kco0zYFe4jA3FRobeUAz3LhX8X4ZgGoc+IiMlsq95twW2CmdpIj5zTyI0Y6WDb9ueo+XgTQCq4g0WJPc3S02P8AgW4yl8KKcGoAAAAASUVORK5CYII=';
const src3='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAABQtJREFUSImllluMXlUVx3//tc/5vm/u49DpTG8gcQpNLxlMoSloow0VCH1BTfuEQnzQRCUaqwaEyDyoryRoVLwEMD4YxhsapUG80Jh4eTGlFkJhLNqZtrR0Ovf5vu+cvZcP33QcyzSirpzkJOes9V9r77X2/7/FWzAHjYIBHAAHGAUBHITE0rf/yhw0sgT6Vnyv9C+7UrWCuFSZnh/Ysd0qYU/0dIOwjeAVoXOZ8+fF+sKoLpyYeArCwVbMv5kuAze1lszTa65fv6atcjsWPhQTu2tSG2Ytr9aDIQr874tl8blbJ46NOkiXbZdWvB3gF/1bBzur+T2VYPdmsi3RE4stlzIYyZPLPQEiOqoZWY4VM0VxcN/pYz8dARtZKvJNK/j9huGPWbDP5tJQ053CU9OzzCwli41CIqE8hxAgJRcQoayiSgZjU3Mze2+bHBtfAnZYauL3BgY6/rBp+PFqFr6ZYGjBY7PhqVQWMp+ZDeXCgipr+8jWrVUqI3FmFiQlkEFeeGoEs3dU2zruFvjoiuHQY5Dv2HTDIx0h+8SFWDSFzHBzMxWzc+rZ9c607uMfsfZt12EheP1v/9Dpbz3JxWd/53lXF8kTOGXNLHM4+vr0xb3vn3ptajnBs+u339aZVX5ZksrSPTdJBKOcnqX7XbvY+sSj5H19WhoCnAiLTX/50w/qjdGfpdDbYypjAlJNZnNFc/++M8cPX+qFtYfsLhOhxM0kIeFFxNprXH3/fcr7+jR9/K+Mf/txFsZOAgG1temakUNeHRyAesNb26WUW7Balt8OMHKpB8HoNkhCIMkkT/U67VuG1L5jC7h7ce4NXrnvIY7ddQ9jnx9h8dQ4bYPr1HXzTpXzC06WCfdQT6VH+R0jrfPVSlBGP5XcTe6OuyeQp+RWq3mo5p5AoaOd0NnJ4qsnWXzlJB4jhnno6cJjkiQPQs3kMcM279sw/MWn11zf9RQEmyvLHxewaFhwJwmwSq7G+BmK1ycl8Ly/n55bbuK6r32F7T95ktrV672IDdVfGnPVqiKWnkBIZFJoy/IvdNdqj/T3Da0Lm+fOn9vcPXBNzcLOpqcCCJbnXj97zqqD/d67+0ZRy+k/sJ+eXTsp6/PkeZsuHP6Nn/7GE8raa5Acd7wWLCujP7OYmocWmvH777vw8lkBHF67bfhtteqvG556Ezim4GUJwbj2Sw8wcPcBJFMiYQmf/NVvefUzD1NOTmHVCinFolNZpe7xB3Onjt57JzSWx/QSST2/cfir7SH75KyXhTkZkqcYzZvN1HXLjdZz801ulQrzfznmk88dEY5n1QplSqkqy0ycmD5ff+8dCy+deQzyj0Ip8GWqeK7j2oG2q3r/JNjUcE8SwQVCxNk5YlFIyBWMrLsTmRFj8oBSVcZ82fjAraeP/3wEshEoVyW7Ixu3fbAaqj+sp9hwKQfk7igLyKzFou5Qlo47SEWnhep8WT70nokXvnw50QGElTrw9pnzL364c7C7O2R7Gh4bjkySSMlJLsXopCSXXFD2hry6mOLX94wfvX818GWyW8HXGpu4+OC8x+90WVYLuLkTkSLupUsxoZhB6LBQnS6LR0+cmjpES/1Wlc1VpW4Esr2bhj8V0AMVs6u8JWzLAY2UJuTp4XePv/Dd1eL/Y4JLyvTHDUMbCzoORmM3Tr/EOUNHZupTP9p//rWzS378T6J/peQri/i/QZbOiQG8CL71X1eVN4n7leyfyt1df6jWQiAAAAAASUVORK5CYII=';
const src4='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAABc1JREFUSImNVWtsVNcRnjn33PW+d71mFz92sS2wDaa2g8CUlBSX1KSIpjRqMUFRUiWRaqSmCWqU33RdqVIl8qNtWlV9pUml0EKQ0sQkQSQCUyvGmAXsAHYpfuAH2OvF68fuXd/XOdMfNlHj2Bbzc3TO9818M985CCsHAwDZ1Fj32MEDO49G/OrXM1ktdfX23Imjxz78LYCWBACgk00KHnxXAgAtB4LLJSkODOMgjx450PTM/oo/VkX9+SBIAnKmWya0tg90H2/97+/yVPXmida2zlWKBGVporl5q/q91w9TetRb+/xTla2b1hf4c7OGaZkCLT1HKlfsms3REhcX+79Zv+6HexvrGs52jXQZuVx6uYKXJnCxVd/pv/7k5Hd3l+7VUllT4YqKgECKCsIWpJApHc48unh9jO9sqMRT711PNLWc3g2pVHYpAf9CFgJEBHrpR08+umVz6FfV6zy7REYXxLhKiCSEZBwM6XRwVFwBfunKHZnVLAm6rpQWebc5TRbRAVYkQESgnx7at635udqPyBbBkE+1Fa5yDyNCBBTAybABx5IZ6r41gCpXYP/jFZjN2XS24+6f9dnk8HIz4IvVAyLAE9+OvVpTlR/suTI2n7g1nRfyOaUQgIYtIauZoBkWulwcdtSspUihX5y/1M//curm2ePvX3wZAMSKBNCyMAvTsnygMKjbEHJNZi2azugAhORhxEqjHsp3ckobNvQOzcGZhCnfPNGNHV0JjW5/hFixjwGAXHaLWtoWxqCS74bCWa1ly2Igm/IYoiSArE4wOimge0CCpq+jyJpHWGlJlRxNTrDL1z5PnuWRf4x1dloPs0UAAGxHff2BV148dDwY8KGh21i6tpDC+UH26dXP6Qd7doFfRdRMkw6+Ghf17D5siBWfeu4P7YcJ0plFwC9Mt9QHSADwjsMxsLPx8RdrKisDjHFrY3kJ5ge8UKyqSIYFrqAfRpJp8M5Ps10bwrA5qNb6/XkVu/vufLB0Fl8xWhwAX5iZscvWhLXN0aInJ7ScEguvYaqqojBMUlx5mOgfwjPn2ihmpYBzFUnPmlVhb62O7ns9w/cuxwFY22IXXyFoWfTEnu93J8DnHfS4fTHgaH3SeQ3O9fU7e4fHoHxbA+TuJ9GbHUe/24l9w/eoriiI8wTR1mv9J88D6C2L8i/7Fi0JDv5w+S/3bnqjdHvjdzCbNj2cHP9O9NCPd5RD72QOZmfS9ERlkX1jYlb9zWeDuz++fP1CHIDFASRbDbl561aVAMSuvDnYUpT/aHmq29b7OrgHbWp49iXoTWp0e/AOloW8qNsWFfqcEA56tgIAxGlBolUJugaEp7Ksuq7hhVde7xyf8mfmDerBYrxqBKC8aiOsffo1VANrqNCtwJwhFb+Tw/biwNMAwAAXCPhK4LW1tZ7QendTQPDns8HcN2ZjbntqXQN/rKGC9KEeFjEnZUfvGG4qi5K0khj0uuTdGY3/J5VJAIBcfBxoxQ5su8oybHOMh6TdNfyBGJ+fBc1fQiGHxGeanqLprI7pM3+DcpxGW1Hx0p1J+mdPGnpTOAoLw8VVJTpypJH4lOd+CcSgIlzNJo0xygzfwEdKCyE1nYHTb/8J6gvddGFolv6emKBPB230u0MQcfMcLDhtdYnGm8fFhcMXLo8cOxfIsCy+8f6b+PKzB0j1eeEXx34Pg7cncMQXQE2XUJwfgXzOIGeaoAvxYD0RVpPo5xgnAGAfX+w4OTGeMfdV7LWEJHbusytCN1CWhYtFxBeUmjBMKS1hWTYxxqSTs+giBMFD+gAKCgo2VVdXu0JR9S0qMWqCEwUQmyFwuB3yzK3Bf31rfdl2j8qjlhDQP5U+8c75tkMP7q4o0f/H1NRUX3t7O2zZWfMh3Bejc1rWtz62sVSA1Me0mbcFInM48kDatnC73F/61R6K4MHZmPNrv770yVT2Z6/t8dj8nvfmSFKM9g/dnazc1uXzKp4cSgoUFHyJ4H8dtayKp0XFAwAAAABJRU5ErkJggg==';
const src5='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAA8hJREFUSImNll2IVVUUx39rn+tcvTqj2EQPmiCUNtigSShjCPVQRPhW2YPQg0L5oAbBxAyFEZQZ+QE9RBBBEBgWRT4YUQ9ORFPNFBmGaFkMiM1cncmP8Y7345z97+Huc+fce2ekBZt92Gfv/1p7ff031MXCvBE4BJwBikAZEODDnB3pWhmYAEaAw0BfC2ZD9gLX5gBqGxbGPP8TYF8r+L6MVdUw+4yVt7tBui8JZ2thfU96jS3A92EDQNSqvSG5HNGhA3QVFuP+GqP81lFKxK27koBbAh4GOBI01losanMLC/NaU5vWsKTRmxUdXLZJmCkyaz2XYh0hBCe94pzggByIfIc2Xp2Q4ljy0rmBd1UARdCqJMU6AzCeCc5tA0u+QxuuFxXLq5IkSm7c0uCzu8XSzrkCrZBdVOYNpDNRt0xRcNGGG5clSXGSKJF0U9Kb3w6pZ6BfBRDOtabwPFY7JwPlsmv5vB64XpSX5GuxsnLx9EUNcpfIBXfOuhaF6CubCuY9WruGeMd22D9IYc1aqFaQuXoFjV7g6s7DXPvuN7gyw8piidUsAYFhTZjNlpvJokjsH9Dy4phelHRM0pc7XlU3C3Rf6bK8JP1wQZ+yXg+xVO9selI/bt6tl1g9mxCzo90tHHxN6xTrdHp/76XtR9XDEt1TmqgvDf+pT3J9wupnl4M6ybW5OtfwiXPgPdrQS+eunXycQG9cheM/MfPNCMWfTzNjOfKJEGBmkCREMpxz/EsCvq3oaFLgvMdve4LnulfSC/gPTnH2+Vd4mfOc5RaXFuVYl9RNNinko8B7rDWIGQUCDO9lYHR18rj3+HIV//kwexf8zpArQWzgPY2scAZWb3lCreAK7UK5TFs1A7hZouActjDP9IpO/q6V6HBgXsS9PbhFC+vWV2JQHdba7W9gulBoYFbffu48V5IaQizrf5ot256iWihQ2fwgyaEDbI3BmcHJUYq6AUa7/bPaqoRyFpAYiI4OPXPsI0lSTdJkqaQXfv1F6/8Z0xu+pkklql0Yl1+1S4+wVNic3JC2inFCQ2pqdu7Obn11aqipUqvpx6Up6bHX9T5r662knSOyWCMRcG+guQSIMEOlGb7+4oTdPRVzf9wF02WiPy7BZ6P4fe/x4cgJ+m2MsuIsL6ZusQYWHLfAw0PA4rCpQTgR8Gh+BVuXreKOGTE1PcFJJhm2UiPAc0iWuLaki3syRFEFEjPz5FwzZUYI12jfrZSZpVvNx8ttnOAstGzLEM/tx7XwgGiS1JV94dkyErLr/z5biiFZ3g4ub2D+Bzw5oABT2hJKAAAAAElFTkSuQmCC';
const src6='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAABetJREFUSIl1lmuMXVUVx/9rn3Of8+jcocxQp4WZzqRMmlpSbENDtAFGbAjGlJhAReqjSvCLMRqJIRqNCX6gHzrRNIgPEgxBDKIJH/xgtRoJFbAPKKVtOszMnTKPe+903vf2nnvO2Xv9/XDuZYZEV3KSk5W9/mevs9f6rQ2SeZKjJNdIutbjnNJaVZIkldY6qiqdc7TWseV3TlVVqaq6IX6tqZlH84UkbXNR81EllR9MhJydi0iScexIKlWVl680uLgUJ4HOkWTrO0rSNjVHQbLWdNhkkapzifiJ55Z1551F7vvMNZ48VaOqsl53/NFPr3Pok0WOPDjN8+82NMmEbn1zH+nVsMHpSGqcpK9nzgW8bXiSQ7sn2TswyYNfmGYYOv7rjRp7+8c5vGeKm7dN8JGvzDEIHF2yMW7UIqkGAJGYqFKcgqqUt//TYBQBbXmDzk7BbMmhXHEYG4sAEWTSgu5ug8tXY87MWoAU50CSgnWj33KQgDFAxhgBCCVFqfCMByOECOB7hPGSeN8DAAFIAQhjDIyhkCAJAQgREQNASIoxkNVVxem36qjMOxz8bB5tbQaV6w6VisXQYAq9vSns3pWB5wHXFxzKFYtP7clgoD+Fi5cCXLgYAhAhVQiKKgXNMtNyxeqhw7Ps7Z/UT98/zcliyL/+rcZDh2f52NES37kQMI4dw9Dxty+s8IGHZvjt75VZKsf83UsrvPX2Cd46XNTRE0skHZuFoghDS1J5/BeLLPSN8479U+zeNs7vPDlPkqzWLMOoVffrtrycxE3PRNy1b4oDO4sc2l3kjjuKHBsPm72j9I0ISMGlKxE6OgysAzZ1GIwXI1SrDrm8wPcEb/w7wJlzDXR2GnxuJI9tW30ogctXQgQBkc0CnmdQrTq8fynE0PY0lIRPJAfY3m4QhUS6G1izQMoXpNIC3wDPHF/GL3+zijgmrAOee34VPz92M+7en0M6Y6AkBAKAUAUKBQ8ihAAwIgKSOPKlTnR1GZTKDvWG4t4DOWQzBi+9UsWx0RU4BQpdHm7p9VEqOXz/qQXMlWLctTeDncNpVK4r5koW992Tw913ZeFUYQwg6hwJwBjBmXMNnDxVx0B/Co8+3Im3zwb4+hPz6OwQDG5P4eKlCGEIZLPA4qLi/vty+PWJHpQqDq+8WkVbm8Hhh9tR2OTBOcIYAZxL2JIATD86xNNv3uC+A9fY3jPO7/6gQtJx5PPT3DI4yR27i9y1b4o9t03wq4+XuLrWQo82AbgORiPNvhMRxLFClXj5j1V8+WgFCwsOW/s8ZDMCawGA+MQtHgoFg0ZADG73cfZ8A0e+UcHVDyKQhLVE67eLCNBEIOPYUlX5/AsrLPSN8+ChGb5/uUEbW8ax5dKS5ciDM7zwXsAXX15lqmuML/5hlWfP19nTP8H9937Iq2MNkutaqkojIlSCvm/w3sUQPzu2zM03eXj2+Gak04Inf7iAP792A/k2gSqRywtyWYGIIJcz8H3BTd0G4xMRnn5mhUFAGCMEQBGBaUGOBE79M8DispWBfh/bB9J49lcrGD22hJP/CJBOAaqEOqAeENGKQxAonAOikOguGJx9pyHXpmMYI+JcwjgfAAUGIkCtDmQyHirzirmylSOPduLDGYu9e9KwFkiKAhgaTGHkgTy2bvEAEmIAwFBVEEUJBFtna5JUkox2DvviGeDGDZWnfrzIQsHDn36/Bd/65ibU60lDvvpaDXvvzODvf+nDPQfyqAdENmsYhiqbuw16e7wmSRNcS3PUwRjhWtXJ1x6fl9dPB8xkIIWCh94eD2TSocVrFkFADA6kkM8J0mlBo0FMTsWoB+TTP+mWJ4520TnCS7BOIVkDkCUBEXrliuPoiVWcf7eBIADSaUrfFg+370hj29YUnCOujMUYG4uwsKSwFuy52eCRL3bgscPtSHREmwOn8bGh35rFJLm84rRUjhgEG0mq3GjLKzFL5ZhRlNw+/t/Q/9i1xTk6a9Wtd6Uyto5RlMyCKHKMY0drkzonlc4qnVP3v64t/wU6HzZC5grEqwAAAABJRU5ErkJggg==';
const src7='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAACHUlEQVRIibWVy2sTURSHv3NnUipC3QgFi0hdaJEuFBRrU0Ni3SnER2njAwUXilREtyJiV/4NroqKpSmipGRh8ZFJQ6Rawe4MiCjio0IXvsDWJnNcJIbY5tmkv9WdM3O/71yYyxHK5OX+sXW//7hBMRwB6UDZAIDoJ0VSqNxf42F85+P+76UYUqw41TvSupi2riB6VpDmck0oOm/gpmW5N7qeHP9aUZDwjx4U5S4iLeXAy036QwynvLFQpLBsCjqRhD98XVTGa4YDiLSoKw8S/vBVRfON5xdJf/ikwp2awcVcqme88dBwXpD0je1zjU4I2I0QoLoI5kBPvP+RAVDjXmwYHEDEg7iDADLVO9KaTltfkOJ/VDa72BFrp2nmFc8vv6lOoqjr2m0mnbEOl4evMIIYKx00CqGGw3NROGSA7aslALoMUPam1plmU8VH9WTeCDq7WnSBWRuYATZVtaNpLesDG7PrXz+Zm/5WYYOmbMABgtXw7W1b2Hot9/DhHXOnpyvskIfyzH+vwyXzuhpBrbFw202305dSmGg8XiN7nGPvTdZkXVJYaBgaFmw8F/g3D7qdvpRRPd8ogcC5LufoRwoHjjceGlYYqheuMNTjDNwqkP2fZGA0qC63VzIyVTix1wlFC8vLbrI3FopkVDsVjS59V7prjWZUO5fCi56gMElf2IchoKq7Edms0Jbr9rPAWxV5YVyeeicHJksx/gJPprnRvoMPtQAAAABJRU5ErkJggg==';
const src8='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAABs1JREFUSIl1VllsldcR/uac8/93v9f4XttQ2xgMXjBbzWI3q4jTgExBgFGj0jaVaNQ0UlMpShvxENQojdSmUZRIqaqSVu0TfWhII4sgVPaSpCnYcQgkGPCKF+B64/ru23/O9AFDSSGfNDrzcL6Z0dF3ZoZwLwgAAxArt1S2Vjr2jnIhHgtBLHUzBQFCljgeZ9M3Qc6pcTidvYfHu+Y4t7lfCXYPWjZXr6ti6/lVbLevZqt0oVYoAcHFxACQI6YYMUalg8+5MPOFKBwak+btnkMjn92v2q9gw+ZFzzaz/eo29kWWFSV8TNoBhAbDzN2XAAsQJGBSxLLXcvABpScvUPHlk4ev7rs7nrztLG2H66GGRS9tYPfrTxf9vjpHFjWB8sTCIYDnzBCgCSgSUCAmCeIaLZ0mtoMp4u+gwVe82h//GP8rZi5TFTyNdvjN3U6gfKGjdFwYiyFIAFAAWyBYINh3nTYIEgRDLEpZ6DXGprSgR6nRHx3sm+25k2Dz5sr6ehHKR4mnfBAdTawAJhAAF4QpCJZRaWhEaromDY0LQ9fn7IY0FJWGRqUWU8KQV0g5DKetbHHgX8OD8TEFQFjseqUo9PTpwyM/r9hc+1SL5X5iWV5qh5i+sAryGOViw8I5myRcZlCeoV2CQIbJEcQFAggEaDasiJiYfQGLvQBA29eFW7Krq44IZivSe239hYgrvF0HjzxfDLhOi7zcr1LHepXe03tw5NyGMvhtAT46gfTtp924saL8zDXLSVwMAUEAJBhxydUNWe+8mtm4opCvI7e0tMQJumBPpn5z/tDQjoZ219/2e9RPPtXZ4+/FEzt3YXrh0i1NB9hf3wwA29KXP+fc6GuuktKL6YT19vebzSORR2JFwyQYgCTmeE7RyKTvj7T1uw1dM22163Jlfg6fHtL+c+MdWb/nS6XoRIHFU+H04M1U2bdPOrUvLigG1gAArGQP1NAbI+7k8U1jqbrqLc3Jf76wJSYBhmGCx9Loi3rwWme4W2i3Ved4LECQyayosArzQ3s9V2eSNskfVIylzqeDTb8uLtmzIDNvIwz5HUM+nSnZhGLtL2sKrsZfnfm4//jApOujWEoaj63ZpbQWxFwRzJsSn7NUGCVCLAVRUctcqUfn6yOtXBl6+v0PBs4kSiZKtXfZmmJgLUud1cRaEBuSJqud4Ho27obW9lIE41nrYjShCMTQhoQxxJaC8Ls5JAAG324hhijZEOHC/NBzW1sqFnMehVv6+HpY4q4vziAigOYYDECIopkVWjOIQFpTwefibFNZNc3zvHjwLCZU+vJ5O9lDWnokkzRMgrXwSJXoJpm90nVwGqmQx1keCTgEEBOYiZgKDnE2R3Ehs8UrKlsEk2AQQWjmZG0JF2pCP9z+QFWLo/tfUkO/u+6NHYXglBKclt7ZI7CG3hixCpdf+eb6xgfqv5FbP7+kyMaQMUwEwYilFWbTqk+pRP6kazrzrWxZgBkMMloYpUx65fyAPZl+y+kv30rVH7XZvddfVb76NWBmyvR9JlIDrx84hf6d23JvtjdnfJY0KDgkiBgAUX/UxvWEOqFoKtWpxuLPqLpw2Ahh2LAkbUS6ImBUS/WDQR7ttG9E9hzo6n1yI3p97gaIg1eQBIDWh+t2ty1PbFxdk9FaEwEkLMG6UBSie9A9MzwhOuWlaDa6YoG/wUS8a/KlHiO0IQIRwMhHfMYp8y0yEk82LQxtsOrCTVRa8sSKRv90nP2Fhxv5Lz99fLY85HXIMYIAQEkjeob99N6Z4N///eHAOxIA15WrEVngjkJlKGBcypAxt8TAoELQbXLVIXe+tmSJ8sgH1fWkyumR35YFyvfsejjZ0VqXRsERAABbGdxMW7Tv6Lxo94D82eSN2IQEgL7R9MSqiJUUBbMpVxWUrKQhwwQmIjYEJYxxW8Z7aSrnjcZ3XZxa6G1bnt63e0PMpQismchlG846gv58PFw8dcn7Qvcng0fungd0aTjZszKgoDLFtkKFX2iP7dxSHJNRgoMDUypw7sZf/3FsbN+jawP7nnl8tnlxWZ41E9vKiFjGoneOlprD5wN7T58c+MM9AwcALg8nPlzlo2n7Zq5VeC2/47VJe23HTuVl8D/Xxiuj4z/SNUse27E2+XJHa0xAgBxHiHOjPvzpWMnkiS+9vzh9auD39x2Zd5JcTXY3+eVJVzTptW9mqlTR+L3Ds+QZnNq7f9Y6074E+3c9lFiQcQjd/X683xWYefds6N1PB1zPdX0ycPj/492vDdxZW3auDa/XYd/3jFIViczQjz2uRc9GgvRWebAYm0mK/htJdWr0mui8dGHg7NetLf8F/g9N4UkPLKgAAAAASUVORK5CYII=';

var ctx = canvas.getContext('2d');
var [cw,ch]=[canvas.width,canvas.height];
//左上角的分数 text,x,y
var [up_text,up_text_x,up_text_y]=[0,10,ch/2-25];
//左下角的分数 text,x,y
var [down_text,down_text_x,down_text_y]=[0,10,ch/2+35]
//中间的河流 x,y,w,h
var [river_x,river_y,river_w,river_h]=[0,(ch/2-100/2),cw,100];
//鱼
var fish_img=new Image();
var is_fish=false;
var fish_i=0;
var fish_fc = 0; //调速变量
fish_img.src=fish_img_src;
fish_img.onload=()=>{
    is_fish=true;
}
var fish_step=5; //移动步数
var [fish_x,fish_y,fish_w,fish_h]=[(cw/2-55/2),(ch/2-37/2),55,37];
var [fish_shake_x,fish_shake_y]=[0,0];
//角色
var player_init_imgs=[src1,src2,src3,src4,src5,src6,src7,src8] //预设角色头像
var player_list=[]; //加载完成的角色
var [player_shake_x,player_shake_y]=[0,0];
var is_player_img=false;
var psz=15;
var player_fc=0 //调速变量
//草
var grass_list=[];
var gr=3; //半径
var grass_tickness=.4; //粗细
var grNum=600; //草的数量
for(let i=0;i<grNum;i++){
    grass_list.push({
        'gx':randomX(),
        'gy':randomY()
    });
}
//游戏方法
function moveUp(){
    if(fish_y>0){
        fish_y-=fish_step;
    }
    if(fish_y<200){
        s1();
    }
}
function moveDown(){
    if(fish_y<=ch-fish_h){
        fish_y+=fish_step;
    }
    if(fish_y>270){
        s2();
    }
}
function s1(){
    up_text+=1;
    down_text-=1;
}
function s2(){
    up_text-=1;
    down_text+=1;
}

document.addEventListener('keydown',(e)=> {
    if (e.key==='ArrowUp'){
        moveUp()
    }else if(e.key==='ArrowDown'){
        moveDown()
    }else if(e.key==='ArrowLeft'){
        loadPlayerImg();
    }else if(e.key==='ArrowRight'){
        player_list=[];
        [up_text,down_text]=[0,0];
        [fish_x,fish_y]=[(cw/2-55/2),(ch/2-37/2)];
    }
});
function gameLoop() {
    ctx.clearRect(0,0,cw,ch);
    drawGrass();
    drawRiver();
    drawScore();
    drawFish();
    drawPlayer();
    requestAnimationFrame(gameLoop);
}
gameLoop();

//工具
function getRandomFromArray(arr) {
    if (!Array.isArray(arr) || arr.length === 0) return undefined;
    const randomIndex = Math.floor(Math.random() * arr.length);
    return arr[randomIndex];
}
function randomY(){
    //随机阵营 上 下
    let campsite=Math.floor(Math.random() * 2) + 1
    let campsite_y;
    if(campsite===1){
        campsite_y=Math.floor(Math.random() * 160) + 15; //上方
    }else{
        campsite_y=Math.floor(Math.random() * 170) + 310 //下方
    }
    return campsite_y;
}
function randomX(){
    //随机x轴
    let campsite_x=Math.floor(Math.random() * 265) + 15;
    return campsite_x;
}
//绘制草
function drawGrass(){
    grass_list.forEach((grass)=>{
        let gx=grass['gx'];
        let gy=grass['gy'];
        ctx.beginPath();
        ctx.lineWidth=grass_tickness;
        ctx.strokeStyle='green';
        // 0 90(0.5*Math.PI) 180(1*Math.PI) 270(1.5*Math.PI)
        ctx.arc(gx, gy, gr, 1.5*Math.PI, 0); //270-0度 左部分
        ctx.arc(gx+gr*2, gy, gr, 1*Math.PI, 1.5*Math.PI); //180-270度 右部分
        ctx.stroke();
    });
}
//绘制河流
function drawRiver(){
    ctx.fillStyle='skyblue';
    ctx.fillRect(river_x,river_y,river_w,river_h);
}
//绘制分数
function drawScore(){
    //左上角分数
    ctx.fillStyle='red';
    ctx.font='16px Arial';
    ctx.fillText(up_text,up_text_x,up_text_y);
    //左下角分数
    ctx.fillText(down_text,down_text_x,down_text_y);
}
//绘制鱼
function drawFish(){
    if(is_fish){
        //每5帧fish_i++
        if(fish_fc%5==0){
            fish_i++;
            if(fish_i==4)fish_i=0;
            fish_shake_x=Math.floor(Math.random() * 3) + 1
            fish_shake_y=Math.floor(Math.random() * 3) + 1
        }
        ctx.drawImage(fish_img, 0,fish_h*fish_i, fish_w,fish_h, fish_x+fish_shake_x,fish_y+fish_shake_y, fish_w,fish_h);
        fish_fc++;
    }
}
//绘制角色
function drawPlayer(){
    if(is_player_img){
        //每10帧浮动一下
        if(player_fc%10==0){
            //随机一个小幅度移动
            player_shake_x=Math.floor(Math.random() * 2) + 1
            player_shake_y=Math.floor(Math.random() * 2) + 1
        }
        player_list.forEach((player,index)=>{
            let pim=player['player_img'];
            let px=player['player_x'];
            let py=player['player_y'];
            if(index%2==0){ //偶数
                //鱼线
                ctx.beginPath();
                ctx.lineWidth=.15;
                ctx.strokeStyle='#999999';
                ctx.moveTo(px+psz/2+player_shake_x,py+psz/2+player_shake_y);
                ctx.lineTo(fish_x+fish_w/2,fish_y+fish_h/2);
                ctx.stroke();
                ctx.drawImage(pim,px+player_shake_x,py+player_shake_y,psz,psz);
            }else{
                //鱼线
                ctx.beginPath();
                ctx.lineWidth=.15;
                ctx.strokeStyle='#999999';
                ctx.moveTo(px+psz/2-player_shake_x,py+psz/2-player_shake_y);
                ctx.lineTo(fish_x+fish_w/2,fish_y+fish_h/2);
                ctx.stroke();
                ctx.drawImage(pim,px-player_shake_x,py-player_shake_y,psz,psz);
            }
            
        })
        player_fc++;
    }
}
//加载角色
function loadPlayerImg(){
    let player_img=new Image();
    //随机一个头像
    player_img.src=getRandomFromArray(player_init_imgs);
    player_img.onload=()=>{
        //加载完成标识
        is_player_img=true;
        let player_dict={
            'player_img':player_img,
            'player_x':randomX(),
            'player_y':randomY()
        };
        player_list.push(player_dict);
    }
}
//抖音方法
var isGift=false;
var isComment=false;
//你自己可以增加一些规则
function findtext(){
    setInterval(function(){
        if(isGift){
            const giftInfo=document.getElementsByClassName('webcast-chatroom___bottom-message');
            if(giftInfo){
                const giftI=giftInfo[giftInfo.length-1];
                try {
                    chrome.storage.local.set({douyinGift: giftI.textContent }).then(() => {
                    });
                } catch (error) {
                }
            }
        }
        if(isComment){
            const commentInfo=document.getElementsByClassName('webcast-chatroom___item webcast-chatroom___enter-done');
            if(commentInfo){
                const commentI=commentInfo[commentInfo.length-1];
                try {
                    chrome.storage.local.set({douyinComment: commentI.textContent }).then(() => {
                    });
                } catch (error) {  
                }
            }
        }
    },300);
}
findtext();
chrome.storage.onChanged.addListener((changes, namespace) => {
    for (let [key, { oldValue, newValue }] of Object.entries(changes)) {
        if(key==='douyinGift'){
            if(oldValue!=newValue){
                console.log('gift...newValue...'+newValue);
                /*if(newValue.includes('来了')){
                    loadPlayerImg(); //增加角色
                }else if(newValue.includes('主播点赞')){
                    //
                }*/
            }
        }else if(key==='douyinComment'){
            if(oldValue!=newValue){
                //这里设置条件来判断鱼是上移还是下移
                /*if(){
                    moveUp();
                }else if(){
                    moveDown();
                }*/
                console.log('comment...newValue...'+newValue);
            }
        }
    }
});
chrome.runtime.onMessage.addListener(async (request,sender,sendResponse)=>{
    if(request.action==='gift'){
        isGift=request.message;
        console.log('gift...request message...'+request.message);
    }else if(request.action==='comment'){
        isComment=request.message;
        console.log('comment...request message...'+request.message);
    }
    return true;
});