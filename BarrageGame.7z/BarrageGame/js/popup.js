console.log('popup.js');
document.addEventListener("DOMContentLoaded", function () {
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
        if(tabs){
            if(tabs.length>0){
                const gift=document.getElementById('gift');
                const comment=document.getElementById('comment');
                chrome.storage.sync.get(['isGift','isComment'],function(data){
                    gift.checked=data.isGift;
                    comment.checked=data.isComment;
                })
                
                gift.addEventListener('click',function(){
                    sendMsg(tabs[0].id,"gift",this.checked);
                    chrome.storage.sync.set({
                        isGift:this.checked
                    })
                });
                comment.addEventListener('click',function(){
                    sendMsg(tabs[0].id,"comment",this.checked);
                    chrome.storage.sync.set({
                        isComment:this.checked
                    })
                });
            }
        }
    });
});

function sendMsg(...args){
    chrome.tabs.sendMessage(args[0],{
        action:args[1],
        message:args[2]
    },function(response){
        if(chrome.runtime.lastError||!response){
        }
    })
}