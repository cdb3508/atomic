console.log('background.js');
chrome.tabs.onUpdated.addListener((tabId,changeInfo,tab)=>{
    if(changeInfo.status==='loading' && tab.url && !tab.url.includes("chrome://")){
        if(tab.url.includes('live.douyin.com')){
            scriptingRegisterContentScripts("douyinbarrage",'./js/douyinbarrage.js');
        }else{
            scriptingRegisterContentScripts('empty','./js/empty.js');
        }
    }
});

async function scriptingRegisterContentScripts(...args){
    const content_script_id=args[0];
    const js_file_name=args[1];
    const existingContentScripts=await chrome.scripting.getRegisteredContentScripts({
        ids:[content_script_id]
    });
    if(existingContentScripts.length>0){
        await chrome.scripting.updateContentScripts([{
            id: content_script_id,
            matches:["<all_urls>"],
            js:[js_file_name]
        }])
        .then(() => console.log("registration updated..."+js_file_name));
    }else{
        await chrome.scripting.registerContentScripts([{
            id:content_script_id,
            js:[js_file_name],
            matches:["<all_urls>"],
            runAt:"document_idle",
        }])
        .then(() => console.log("registration complete..."+js_file_name))
        .catch((err) => console.warn("unexpected error", err))
    }
}
